const website = {
    name: "Trivana Textile",
    phone: "+12893020086",
    displayPhone: "+1 (289) 302-0086",
};

export default website;
