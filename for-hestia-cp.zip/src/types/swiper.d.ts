// src/types/swiper.d.ts
declare module "swiper";
